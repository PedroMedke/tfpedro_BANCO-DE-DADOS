Parte 1
1. Banco de Dados como Documentos: MongoDB
Justificativa: 
- Suporte a consultas complexas e filtros dinâmicos.
- Possui escalabilidade horizontal nativa com sharding integrado.


Parte 2
1. Escalabilidade Horizontal
Justificativa: 
- Suporte a crescimento quase ilimitado, adicionando mais nós ao cluster.
- Maior resiliência e tolerância a falhas.
- Melhor custo-benefício a longo prazo, evitando os limites físicos de hardware.

2. Tipo de Sharding: Geográfico
Chave de Partição: origem.estado ou destino.estado
Justificativa: 
- Entregas geralmente ocorrem dentro de regiões específicas.
- Agrupar dados por estado melhora a localidade dos dados, reduz latências nas consultas.
- Minimiza o tráfego entre shards para consultas regionais.


Parte 4
1. Métricas críticas
1° Taxa de latência das consultas
Porque monitorar: Garantir respostas rápidas; detectar gargalos

2° OpCounters (Taxa de Leitura/Escrita)
Porque monitorar: Entender carga no banco e prever escalabilidade

3° Uso de memória (Working set)
Porque monitorar: Se o conjunto de dados ativo não cabe na RAM, a performance degrada

2. Crescimento desbalanceado — por exemplo, estados como SP e RJ concentram muitas entregas, enquanto outros estão subutilizados.

solução: 
- Avaliar se a chave de sharding continua adequada.
- No MongoDB, o balancer identifica chunks desbalanceados e os redistribui automaticamente.
- Se necessário, alterar a estratégia de sharding (ex.: de geográfico para hash).
- Executar manualmente o split de chunks muito grandes: