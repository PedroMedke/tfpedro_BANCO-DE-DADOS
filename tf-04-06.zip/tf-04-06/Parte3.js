// 1. Consulta: Buscar entregas "em trânsito" de um cliente
db.entregas.find(
  { 
    id_cliente: "cliente_98765", 
    status: "em_transito" 
  }
)

// 2.Otimizações
db.entregas.createIndex({ id_cliente: 1, status: 1 })
//Otimiza buscas filtrando por cliente e status.

//Projeção de campos
db.entregas.find(
  { id_cliente: "cliente_98765", status: "em_transito" },
  { origem: 1, destino: 1, status: 1, _id: 0 }
)
//Retorna apenas os campos necessários, reduzindo carga de rede e processamento.

// uso de explain
db.entregas.find(
  { id_cliente: "cliente_98765", status: "em_transito" }
).explain("executionStats")

