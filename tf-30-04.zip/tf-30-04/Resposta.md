# cliente 
-Referenciado
-Clientes podem fazer muitos pedidos. Embutir dados duplicaria informações.
# entregador
-Referenciado
-Um entregador faz muitas entregas. Evitamos redundância referenciando.
# pedido
-embutido
-Principal entidade de leitura/análise. Armazena os dados centrais.
# produto
-embutido
-Preço e nome no momento do pedido são fixos, então embutir garante histórico.