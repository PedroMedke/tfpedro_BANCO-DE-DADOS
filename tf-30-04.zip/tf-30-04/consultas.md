# alternativa "A"
const entregador = db.entregadores.findOne({ nome: "Carlos Mendes" });

db.pedidos.find({
    entregador_id: entregador._id,
  status: "entregue"
})
    
# alternativa "B"
db.pedidos.aggregate([
  { $unwind: "$produtos" },
  { $group: {
    _id: "$produtos.nome",
    total_vendido: { $sum: 1 }
  }},
  { $sort: { total_vendido: -1 } }
]);

# alternativa "C"
db.pedidos.createIndex({ local: "2dsphere" });
db.pedidos.find({
  local: {
    $near: {
      $geometry: {
        type: "Point",
        coordinates: [-46.634, -23.551]
      },
      $maxDistance: 1000
    }
  }
});

# alternativa "D"
db.pedidos.find({
  "produtos.nome": "Pizza Calabresa"
});

# alternativa "E"
db.pedidos.aggregate([
  {
    $lookup: {
      from: "clientes",
      localField: "cliente_id",
      foreignField: "_id",
      as: "cliente"
    }
  },
  { $unwind: "$cliente" },
  {
    $project: {
      _id: 0,
      nome_cliente: "$cliente.nome",
      produtos: "$produtos.nome"
    }
  }
]);
